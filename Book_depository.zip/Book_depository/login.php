<?php 


$uname=$_GET['uname'];
$pass=$_GET['psw'];
error_reporting(0);
$con=mysqli_connect("localhost","root","") OR die("server is not found");
echo "server is connected";
$db=mysqli_select_db($con,"demo");
if($db)
{
echo "database selected";
$query="select psw from login where uname='".$uname."';";
echo $query;
$result=mysqli_query($con,$query);
$row=mysqli_fetch_array($result);
$serverpass=$row['psw'];

}
else{
	echo "database not found:";
}	
if($pass==$serverpass)
{
	echo "loged in";
		header("location:test.html");
}
else{
	echo "not logged in:";
	
}
?>
