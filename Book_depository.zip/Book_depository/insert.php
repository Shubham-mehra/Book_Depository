<?php
$Fname=$_GET['Fname'];
$Lname=$_GET['Lname'];
$email=$_GET['email'];
$con=mysqli_connect("localhost","root","") OR die("could not connect to the server");
$db=mysqli_select_db($con,"demo");
if($db)
{
$query="insert into contact values('".$Fname."','".$Lname."','".$email."');";
	if(mysqli_query($con,$query))
	{
	$message = "complain has been Submitted \\nWe will connect you Soon.";
  echo "<script type='text/javascript'>alert('$message');</script>";
	header("location:index.html");	
	}
}
else
{
echo "database is not selected","<br>";
}
?>