<?php
$Bname=$_GET['bname'];
$Bauthor=$_GET['bauthor'];
$Bpublisher=$_GET['bpublisher'];
$Bcost=$_GET['bcost'];
$con=mysqli_connect("localhost","root","") OR die("could not connect to the server");
$db=mysqli_select_db($con,"demo");
if($db)
{
$query="insert into Bookdetail values('".$Bname."','".$Bauthor."','".$Bpublisher."','".$Bcost."');";
	if(mysqli_query($con,$query))
	{
	$message = "complain has been Submitted \\nWe will connect you Soon.";
  echo "<script type='text/javascript'>alert('$message');</script>";
	header("location:index.html");	
	}
}
else
{
echo "database is not selected","<br>";
}
?>