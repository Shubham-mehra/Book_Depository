<?php
$bname=$_GET['bname'];
$Bauthor=$_GET['Bauthor'];
$bpublisher=$_GET['bpublisher'];
$cusname=$_GET['cusname'];
$cuscontact=$_GET['cuscontact'];
$cusemail=$_GET['cusemail'];
$con=mysqli_connect("localhost","root","") OR die("could not connect to the server");
$db=mysqli_select_db($con,"demo");
if($db)
{
$query="insert into Bookdetailbuy values('".$bname."','".$bauthor."','".$bpublisher."','".$cusname."','".$cuscontact."','".$cusemail."');";
	if(mysqli_query($con,$query))
	{
	$message = "complain has been Submitted \\nWe will connect you Soon.";
  echo "<script type='text/javascript'>alert('$message');</script>";
	header("location:index.html");	
	}
}
else
{
echo "database is not selected","<br>";
}
?>