
function imag(){
document.getElementById('Image').src='images/global.png';
}

function imag1(){
document.getElementById('Image').src='images/head.png';
}

function imag2(){
document.getElementById('Image').src='images/struct.jpg';
}
function imag4(){
document.getElementById('Image').src='images/phone.png';
}
function imag3(){
document.getElementById('Image').src='images/mail.png';
}
function lev()
{
   document.getElementById('image').src='images/reuse2.png';
}
