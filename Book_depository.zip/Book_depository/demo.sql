-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2018 at 01:36 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookdetail`
--

CREATE TABLE IF NOT EXISTS `bookdetail` (
  `Bname` varchar(50) NOT NULL,
  `Bauthor` varchar(50) NOT NULL,
  `Bpublisher` varchar(50) NOT NULL,
  `Bcost` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookdetail`
--

INSERT INTO `bookdetail` (`Bname`, `Bauthor`, `Bpublisher`, `Bcost`) VALUES
('aldflka', 'ladsflka', 'kasdkfdsk', 25),
('this', 'hello', 'this', 25);

-- --------------------------------------------------------

--
-- Table structure for table `bookdetailbuy`
--

CREATE TABLE IF NOT EXISTS `bookdetailbuy` (
  `bname` varchar(52) NOT NULL,
  `bauthor` varchar(50) NOT NULL,
  `bpublisher` varchar(50) NOT NULL,
  `cusname` varchar(50) NOT NULL,
  `cuscontact` varchar(50) NOT NULL,
  `cusemail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookdetailbuy`
--

INSERT INTO `bookdetailbuy` (`bname`, `bauthor`, `bpublisher`, `cusname`, `cuscontact`, `cusemail`) VALUES
('aldflka', '', 'kasdkfdsk', 'kjdflkajsd', '25', 'mehrashubham32@gmail.com'),
('thsi', '', 'sadkfas', 'adfas', '255415', 'jfjyjfjhgkjgkjg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `Fname` varchar(52) NOT NULL,
  `Lname` varchar(52) NOT NULL,
  `email` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Fname`, `Lname`, `email`) VALUES
('kdfkal', '', 'mehrashubham32@gmail.com'),
('hello', '', 'mehrashubham32@gmail.com'),
('', '', ''),
('', '', ''),
('', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `uname` varchar(50) NOT NULL,
  `psw` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE IF NOT EXISTS `mail` (
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mail`
--

INSERT INTO `mail` (`Email`) VALUES
('mehrashubham32@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
